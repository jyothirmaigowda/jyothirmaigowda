# 🌿 CampusShare — Campus Resource Sharing Platform

A full-stack MVP for students to lend and borrow items within a college campus.

---

## 📁 Project Structure

```
campusshare/
├── backend/                  # Node.js + Express API
│   ├── models/
│   │   ├── User.js           # User schema (name, email, coins)
│   │   ├── Item.js           # Item schema (title, category, availability)
│   │   └── BorrowRequest.js  # Request schema (status: pending/approved/rejected)
│   ├── routes/
│   │   ├── auth.js           # POST /signup, POST /login
│   │   ├── items.js          # CRUD for items
│   │   ├── requests.js       # Borrow request flow
│   │   └── users.js          # Profile management
│   ├── middleware/
│   │   └── auth.js           # JWT verification
│   ├── server.js             # Express app entry
│   └── .env.example          # Environment variables template
│
└── frontend/                 # React app
    └── src/
        ├── context/
        │   └── AuthContext.js     # Global auth state
        ├── utils/
        │   └── api.js             # Axios API helpers
        ├── components/
        │   ├── Navbar.js          # Navigation bar
        │   └── ItemCard.js        # Reusable item card
        ├── pages/
        │   ├── Home.js            # Browse + search items
        │   ├── AuthPage.js        # Login / Signup
        │   ├── AddItem.js         # Create item form
        │   ├── ItemDetail.js      # Item page + borrow request
        │   ├── Requests.js        # Received & sent requests
        │   └── Profile.js         # Dashboard + my items
        ├── App.js                 # Router setup
        └── index.css              # Global design system
```

---

## 🚀 Running Locally

### Prerequisites
- Node.js 18+ installed
- MongoDB running locally **OR** a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster

---

### 1. Start the Backend

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI if needed
npm run dev
```

The API will start at **http://localhost:5000**

**API Endpoints:**
| Method | Route | Auth | Description |
|--------|-------|------|-------------|
| POST | /api/auth/signup | ❌ | Register a new user |
| POST | /api/auth/login | ❌ | Login, returns JWT |
| GET | /api/items | ❌ | Browse all available items |
| GET | /api/items/my | ✅ | Get my listed items |
| POST | /api/items | ✅ | Create a new item |
| DELETE | /api/items/:id | ✅ | Delete my item |
| POST | /api/requests | ✅ | Send borrow request |
| GET | /api/requests/received | ✅ | Requests received (as owner) |
| GET | /api/requests/sent | ✅ | Requests sent (as borrower) |
| PATCH | /api/requests/:id/status | ✅ | Approve / reject / returned |
| GET | /api/users/me | ✅ | Get my profile |
| PUT | /api/users/me | ✅ | Update my profile |

---

### 2. Start the Frontend

```bash
cd frontend
npm install
npm start
```

The app will open at **http://localhost:3000**

> The `"proxy": "http://localhost:5000"` in `frontend/package.json` forwards all `/api` calls to the backend automatically.

---

## ✨ Features Implemented

| Feature | Status |
|---------|--------|
| Sign up / Login with JWT | ✅ |
| Browse all items | ✅ |
| Search by name | ✅ |
| Filter by category | ✅ |
| List a new item (with image upload) | ✅ |
| Item detail page | ✅ |
| Send borrow request | ✅ |
| Approve / Reject requests | ✅ |
| Mark item as returned | ✅ |
| Coins reward system (+10 on return) | ✅ |
| Dashboard with my items & stats | ✅ |
| Edit profile (name, college, bio) | ✅ |
| Toggle item availability | ✅ |
| Mobile responsive UI | ✅ |
| Works with mock data (no backend) | ✅ |

---

## 🎨 Tech Stack

- **Frontend:** React 18, React Router v6, Axios
- **Backend:** Node.js, Express 4
- **Database:** MongoDB with Mongoose
- **Auth:** JWT (jsonwebtoken) + bcryptjs
- **File uploads:** Multer
- **Fonts:** Syne (display) + Instrument Sans (body)

---

## 🪙 Coins System

- Every new user starts with **50 coins**
- When an owner marks a borrowed item as **returned**, they earn **+10 coins**
- Item owners can set a **coins required** value that borrowers must have

---

## 📝 Environment Variables

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/campusshare
JWT_SECRET=your_secret_key_here
```

---

## 🔮 Possible Next Steps

- Email notifications on request status change
- In-app messaging between borrower and owner
- Star/rating system after a successful borrow
- QR code for item handoff verification
- Campus-based filtering (multi-college support)
- PWA support for mobile
