const express = require('express');
const router = express.Router();
const BorrowRequest = require('../models/BorrowRequest');
const Item = require('../models/Item');
const User = require('../models/User');
const auth = require('../middleware/auth');

// POST /api/requests — create borrow request
router.post('/', auth, async (req, res) => {
  try {
    const { itemId, message, borrowFrom, borrowTo } = req.body;
    const item = await Item.findById(itemId);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    if (!item.isAvailable) return res.status(400).json({ message: 'Item is not available' });
    if (item.owner.toString() === req.user.id) {
      return res.status(400).json({ message: 'You cannot request your own item' });
    }
    // Check for existing pending request
    const existing = await BorrowRequest.findOne({ item: itemId, borrower: req.user.id, status: 'pending' });
    if (existing) return res.status(400).json({ message: 'You already have a pending request for this item' });

    const request = new BorrowRequest({
      item: itemId,
      borrower: req.user.id,
      owner: item.owner,
      message,
      borrowFrom,
      borrowTo
    });
    await request.save();
    const populated = await request.populate([
      { path: 'item', select: 'title category image' },
      { path: 'borrower', select: 'name email' },
      { path: 'owner', select: 'name email' }
    ]);
    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/requests/received — requests received by logged-in user (as owner)
router.get('/received', auth, async (req, res) => {
  try {
    const requests = await BorrowRequest.find({ owner: req.user.id })
      .populate('item', 'title category image')
      .populate('borrower', 'name email college')
      .sort({ createdAt: -1 });
    res.json(requests);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/requests/sent — requests sent by logged-in user (as borrower)
router.get('/sent', auth, async (req, res) => {
  try {
    const requests = await BorrowRequest.find({ borrower: req.user.id })
      .populate('item', 'title category image')
      .populate('owner', 'name email college')
      .sort({ createdAt: -1 });
    res.json(requests);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PATCH /api/requests/:id/status — approve or reject
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    if (!['approved', 'rejected', 'returned'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }
    const request = await BorrowRequest.findById(req.params.id);
    if (!request) return res.status(404).json({ message: 'Request not found' });
    if (request.owner.toString() !== req.user.id) return res.status(403).json({ message: 'Not authorized' });

    request.status = status;
    await request.save();

    // If approved: mark item unavailable
    if (status === 'approved') {
      await Item.findByIdAndUpdate(request.item, { isAvailable: false });
    }
    // If returned: mark item available again + reward owner with coins
    if (status === 'returned') {
      await Item.findByIdAndUpdate(request.item, { isAvailable: true });
      await User.findByIdAndUpdate(request.owner, { $inc: { coins: 10 } });
    }

    const populated = await request.populate([
      { path: 'item', select: 'title category image' },
      { path: 'borrower', select: 'name email' }
    ]);
    res.json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
