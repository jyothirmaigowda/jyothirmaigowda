const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  category: {
    type: String,
    required: true,
    enum: ['Books', 'Electronics', 'Sports', 'Stationery', 'Clothing', 'Tools', 'Kitchen', 'Other']
  },
  image: { type: String, default: '' },
  availableFrom: { type: Date, default: Date.now },
  availableTo: { type: Date },
  isAvailable: { type: Boolean, default: true },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  coinsRequired: { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Item', itemSchema);
