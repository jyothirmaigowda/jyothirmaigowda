import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { itemsAPI, usersAPI } from '../utils/api';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [myItems, setMyItems] = useState([]);
  const [loadingItems, setLoadingItems] = useState(true);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: user?.name || '', college: user?.college || '', bio: user?.bio || '' });
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    itemsAPI.getMy()
      .then(r => setMyItems(r.data))
      .catch(() => setMyItems([]))
      .finally(() => setLoadingItems(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await usersAPI.updateMe(form);
      updateUser(res.data);
      setEditing(false);
    } catch { setError('Failed to update profile'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this item?')) return;
    setDeleting(id);
    try {
      await itemsAPI.delete(id);
      setMyItems(items => items.filter(i => i._id !== id));
    } catch { alert('Failed to delete item'); }
    finally { setDeleting(null); }
  };

  const handleToggle = async (item) => {
    try {
      await itemsAPI.update(item._id, { isAvailable: !item.isAvailable });
      setMyItems(items => items.map(i => i._id === item._id ? { ...i, isAvailable: !i.isAvailable } : i));
    } catch { alert('Failed to update'); }
  };

  const avatarLetter = (user?.name || 'U')[0].toUpperCase();
  const availableCount = myItems.filter(i => i.isAvailable).length;

  return (
    <div style={{ padding: '36px 0 60px' }}>
      <div className="container" style={{ maxWidth: 800 }}>
        {/* Profile card */}
        <div style={styles.profileCard} className="fade-up">
          <div style={styles.avatar}>{avatarLetter}</div>
          <div style={styles.profileInfo}>
            {editing ? (
              <div style={styles.editForm}>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Name" style={styles.editInput} />
                <input value={form.college} onChange={e => setForm(f => ({ ...f, college: e.target.value }))} placeholder="College" style={styles.editInput} />
                <input value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} placeholder="Short bio" style={styles.editInput} />
                {error && <div style={{ color: '#ef4444', fontSize: 12 }}>{error}</div>}
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={handleSave} style={styles.saveBtn} disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
                  <button onClick={() => setEditing(false)} style={styles.cancelBtn}>Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <h2 style={styles.name}>{user?.name}</h2>
                <p style={styles.email}>{user?.email}</p>
                {user?.college && <p style={styles.college}>🏫 {user.college}</p>}
                {user?.bio && <p style={styles.bio}>{user.bio}</p>}
                <button onClick={() => setEditing(true)} style={styles.editBtn}>✏️ Edit Profile</button>
              </>
            )}
          </div>

          {/* Stats */}
          <div style={styles.statsRow}>
            <div style={styles.stat}>
              <div style={styles.statVal}>🪙 {user?.coins ?? 50}</div>
              <div style={styles.statLabel}>Coins</div>
            </div>
            <div style={styles.statDivider} />
            <div style={styles.stat}>
              <div style={styles.statVal}>{myItems.length}</div>
              <div style={styles.statLabel}>Items Listed</div>
            </div>
            <div style={styles.statDivider} />
            <div style={styles.stat}>
              <div style={styles.statVal}>{availableCount}</div>
              <div style={styles.statLabel}>Available</div>
            </div>
          </div>
        </div>

        {/* My Items */}
        <div style={{ marginTop: 32 }} className="fade-up">
          <div style={styles.sectionHeader}>
            <h2 style={styles.sectionTitle}>My Shared Items</h2>
            <Link to="/add-item" style={styles.addBtn}>＋ Add Item</Link>
          </div>

          {loadingItems ? (
            <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" /></div>
          ) : myItems.length === 0 ? (
            <div style={styles.emptyState}>
              <div style={{ fontSize: 40 }}>📦</div>
              <p>You haven't listed any items yet.</p>
              <Link to="/add-item" style={styles.addBtnLarge}>Share your first item →</Link>
            </div>
          ) : (
            <div style={styles.itemList}>
              {myItems.map(item => (
                <div key={item._id} style={styles.itemRow}>
                  <div style={styles.itemLeft}>
                    <div style={styles.itemIcon}>
                      {{ Books:'📚', Electronics:'💻', Sports:'⚽', Stationery:'✏️', Clothing:'👕', Tools:'🔧', Kitchen:'🍳', Other:'📦' }[item.category] || '📦'}
                    </div>
                    <div>
                      <div style={styles.itemTitle}>{item.title}</div>
                      <div style={styles.itemCategory}>{item.category}</div>
                    </div>
                  </div>
                  <div style={styles.itemRight}>
                    <button
                      onClick={() => handleToggle(item)}
                      style={{ ...styles.toggleBtn, ...(item.isAvailable ? styles.toggleOn : styles.toggleOff) }}
                    >
                      {item.isAvailable ? '✅ Available' : '🔴 Unavailable'}
                    </button>
                    <button
                      onClick={() => handleDelete(item._id)}
                      style={styles.deleteBtn}
                      disabled={deleting === item._id}
                    >
                      {deleting === item._id ? '…' : '🗑️'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Coins info */}
        <div style={styles.coinsInfo} className="fade-up">
          <div style={{ fontSize: 28 }}>🪙</div>
          <div>
            <strong>Earn more coins</strong>
            <p style={{ fontSize: 13, color: '#6b7280', marginTop: 2 }}>Share items and mark them as returned to earn +10 coins each time. Coins can be used to borrow premium items.</p>
          </div>
          <div style={styles.coinsBig}>{user?.coins ?? 50}</div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  profileCard: { background: '#fff', border: '1px solid #e5e7e0', borderRadius: 16, padding: '24px', display: 'flex', gap: 20, alignItems: 'flex-start', flexWrap: 'wrap' },
  avatar: { width: 64, height: 64, borderRadius: '50%', background: 'linear-gradient(135deg, #1a6b3c, #22c55e)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 800, fontFamily: 'Syne, sans-serif', flexShrink: 0 },
  profileInfo: { flex: 1, minWidth: 180 },
  name: { fontFamily: 'Syne, sans-serif', fontSize: 20, fontWeight: 800, marginBottom: 2 },
  email: { fontSize: 13, color: '#6b7280' },
  college: { fontSize: 13, color: '#6b7280', marginTop: 4 },
  bio: { fontSize: 14, color: '#4a4a45', marginTop: 6 },
  editBtn: { marginTop: 10, padding: '6px 14px', borderRadius: 8, fontSize: 13, fontWeight: 600, background: '#f3f4f6', color: '#374151', border: 'none', cursor: 'pointer' },
  editForm: { display: 'flex', flexDirection: 'column', gap: 8 },
  editInput: { padding: '8px 12px', borderRadius: 8, border: '1.5px solid #e5e7e0', fontSize: 14 },
  saveBtn: { padding: '7px 16px', borderRadius: 8, fontSize: 13, fontWeight: 700, background: '#1a6b3c', color: '#fff', border: 'none', cursor: 'pointer' },
  cancelBtn: { padding: '7px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, background: '#f3f4f6', color: '#374151', border: 'none', cursor: 'pointer' },
  statsRow: { display: 'flex', alignItems: 'center', gap: 16, marginLeft: 'auto', background: '#f9fafb', borderRadius: 12, padding: '14px 20px' },
  stat: { textAlign: 'center' },
  statVal: { fontFamily: 'Syne, sans-serif', fontSize: 18, fontWeight: 800 },
  statLabel: { fontSize: 11, color: '#9a9a90', marginTop: 2 },
  statDivider: { width: 1, height: 32, background: '#e5e7e0' },
  sectionHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontFamily: 'Syne, sans-serif', fontSize: 20, fontWeight: 800 },
  addBtn: { padding: '8px 18px', borderRadius: 99, fontSize: 13, fontWeight: 700, background: '#1a6b3c', color: '#fff', textDecoration: 'none' },
  emptyState: { textAlign: 'center', padding: '40px 0', color: '#9a9a90', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 },
  addBtnLarge: { padding: '10px 22px', borderRadius: 99, background: '#f0fdf4', color: '#1a6b3c', fontWeight: 700, fontSize: 14, textDecoration: 'none', border: '1px solid #d1fae5' },
  itemList: { display: 'flex', flexDirection: 'column', gap: 10 },
  itemRow: { background: '#fff', border: '1px solid #e5e7e0', borderRadius: 12, padding: '14px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 },
  itemLeft: { display: 'flex', gap: 12, alignItems: 'center' },
  itemIcon: { fontSize: 28 },
  itemTitle: { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14 },
  itemCategory: { fontSize: 12, color: '#9a9a90', marginTop: 2 },
  itemRight: { display: 'flex', gap: 8, alignItems: 'center' },
  toggleBtn: { padding: '6px 14px', borderRadius: 99, fontSize: 12, fontWeight: 700, border: '1.5px solid', cursor: 'pointer' },
  toggleOn: { background: '#f0fdf4', color: '#1a6b3c', borderColor: '#d1fae5' },
  toggleOff: { background: '#fef2f2', color: '#ef4444', borderColor: '#fecaca' },
  deleteBtn: { padding: '6px 10px', borderRadius: 8, fontSize: 14, background: '#fff', border: '1.5px solid #e5e7e0', cursor: 'pointer' },
  coinsInfo: { marginTop: 24, background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 14, padding: '18px 20px', display: 'flex', gap: 16, alignItems: 'center' },
  coinsBig: { fontFamily: 'Syne, sans-serif', fontSize: 32, fontWeight: 800, color: '#b45309', marginLeft: 'auto' },
};
